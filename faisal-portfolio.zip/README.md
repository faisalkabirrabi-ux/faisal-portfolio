# Faisal Kabir Rabi - Portfolio

## Run it on your computer
1. Install Node.js (LTS) from https://nodejs.org
2. Open a terminal inside this folder.
3. `npm install`  (downloads the tools, takes ~1 minute)
4. `npm run dev`  (open the address it prints, usually http://localhost:5173)

## Edit your information
Open `src/data/content.js`. Replace every [bracketed] placeholder, your email and GitHub link.
Put your two CV PDFs in `public/cv/` (names are in that folder's README.txt).

## Publish
1. Create a free GitHub account and a new empty repository.
2. In the terminal: `git init`, `git add .`, `git commit -m "first version"`, then run the 3 commands GitHub shows (`git remote add origin ...`, `git branch -M main`, `git push -u origin main`).
3. Go to https://vercel.com, sign in with GitHub, click Add New > Project, pick your repo, click Deploy. Vercel detects Vite automatically.
